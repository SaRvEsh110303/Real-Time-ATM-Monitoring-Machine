package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.ATMDetails;
import com.example.Repository.ATMDetailsRepository;

@RestController
@RequestMapping("/atm")
public class ATMDetailsController {

	@Autowired
    private ATMDetailsRepository atmDetailsRepository;

    @GetMapping("/get")
    public List<ATMDetails> getAllATMDetails() {
        return atmDetailsRepository.getAllATMDetails();
    }

    @PostMapping("/add")
    public ResponseEntity<String> createATMDetails(@RequestBody ATMDetails atmDetails) {
         atmDetailsRepository.addATMDetails(atmDetails);
         return ResponseEntity.ok("ATM Details added successfully");
    }
}
