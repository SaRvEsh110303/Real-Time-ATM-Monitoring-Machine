package com.example.Controller;
//
//import java.beans.ConstructorProperties;
//import java.net.URISyntaxException;
//import java.nio.charset.StandardCharsets;
//import java.util.List;
//
//import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
//import org.eclipse.paho.client.mqttv3.MqttCallback;
//import org.eclipse.paho.client.mqttv3.MqttClient;
//import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
//import org.eclipse.paho.client.mqttv3.MqttException;
//import org.eclipse.paho.client.mqttv3.MqttMessage;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.azure.messaging.servicebus.ServiceBusClientBuilder;
//import com.azure.messaging.servicebus.ServiceBusProcessorClient;
//import com.azure.messaging.servicebus.ServiceBusReceivedMessageContext;
//import com.example.Entity.CashFlow;
//import com.example.Entity.Temperature;
//import com.example.Repository.CashFlowRepository;
//import com.example.Services.IotHubService;
//import com.example.Services.ServiceBusService;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.microsoft.azure.sdk.iot.device.DeviceClient;
//import com.microsoft.azure.sdk.iot.device.IotHubClientProtocol;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.CashFlow;
import com.example.Repository.CashFlowRepository;
import com.example.Services.IotHubService;
import com.microsoft.azure.sdk.iot.device.Message;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;

@RestController
@RequestMapping("/cashflow")
public class CashFlowController {
	private CashFlowRepository cashFlowRepository;
    private static final Logger logger = LoggerFactory.getLogger(CashFlowController.class);


	private IotHubService iotHubService;
	public CashFlowController(IotHubService iotHubService) {
		this.iotHubService=iotHubService;
	}
	
	@CrossOrigin(origins = "http://127.0.0.1:5500")
	@PostMapping("/depositing")
	public ResponseEntity<String> updateCashFlow(@RequestBody Map<String, Object> cashFlow){
		try {
			

			iotHubService.sendCashflowData(cashFlow);
			////
			return ResponseEntity.ok("CashFlow Recorded and sent to IOT HUB Successfully!");
			}catch (Exception e) {
				// TODO: handle exception
				return ResponseEntity.badRequest().body("Error Converting data to JSON: "+e.getMessage());
			}
				}
	
	  @GetMapping("/latest")
	    public ResponseEntity<CashFlow> getLatestCashFlow(@RequestParam String atmId) {
	        try {
	            CashFlow latestCashFlow = cashFlowRepository.findTopByAtmIdOrderByidDesc(atmId);
	            if (latestCashFlow != null) {
	                return ResponseEntity.ok(latestCashFlow);
	            } else {
	                return ResponseEntity.notFound().build();
	            }
	        } catch (Exception e) {
	            logger.error("Error fetching latest cashflow data", e);
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	        }
	    }
	@CrossOrigin(origins = "http://127.0.0.1:5500")
	@GetMapping("/getDeposits")
	public ResponseEntity<List<CashFlow>> getCashFlow(){
		List<CashFlow> cashFlow = cashFlowRepository.getAllCashFlows();
		return cashFlow !=null ? ResponseEntity.ok(cashFlow): ResponseEntity.notFound().build();
	}
}
