package com.example.Controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.CashFlow;
import com.example.Entity.Temperature;
import com.example.Repository.CashFlowRepository;
import com.example.Repository.TemperatureRepository;

@RestController
@RequestMapping("/latestData")
public class LatestDataController {
		@Autowired
		private CashFlowRepository cashFlowRepository;
		@Autowired
		private TemperatureRepository temperatureRepository;
		Logger logger = LoggerFactory.getLogger(LatestDataController.class);
	@CrossOrigin(origins = "http://127.0.0.1:5500")
@GetMapping("/data")
public ResponseEntity<Map<String, Object>> getLatestData(@RequestParam String atm_id) {
    try {
        CashFlow latestCashFlow = cashFlowRepository.findTopByAtmIdOrderByidDesc(atm_id);
        Temperature latestTemperature = temperatureRepository.findTopByAtmIdOrderByidDesc(atm_id);

        if (latestCashFlow != null && latestTemperature != null) {
            Map<String, Object> response = new HashMap<>();
            response.put("total_cash", latestCashFlow.getTotalCash());
            response.put("notes_100", latestCashFlow.getNotes_100());
            response.put("notes_200", latestCashFlow.getNotes_200());
            response.put("notes_500", latestCashFlow.getNotes_500());
            response.put("value", latestTemperature.getValue());

            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.notFound().build();
        }
    } catch (Exception e) {
        logger.error("Error fetching latest data", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }
}


}
