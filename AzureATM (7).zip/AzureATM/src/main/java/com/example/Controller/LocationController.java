package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Location;
import com.example.Repository.LocationRepository;

@RestController
@RequestMapping("/location")
public class LocationController {

	 @Autowired
	    private LocationRepository locationRepository;

	    @GetMapping("/get")
	    public List<Location> getAllLocations() {
	        return locationRepository.getAllLocations();
	    }

	    @PostMapping("/add")
	    public ResponseEntity<String> createLocation(@RequestBody Location location) {
	        locationRepository.addLocation(location);
	        return ResponseEntity.ok("Location added successfully");
	    }

}
