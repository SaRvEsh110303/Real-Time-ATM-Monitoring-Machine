package com.example.Controller;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.azure.messaging.servicebus.ServiceBusSenderClient;
import com.example.Entity.Temperature;
import com.azure.messaging.servicebus.*;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.example.Repository.TemperatureRepository;
import com.example.Services.IotHubService;

@RestController
@RequestMapping("/temperature")
public class TemperatureController {
	@Autowired
	private TemperatureRepository temperatureRepository;
    private static final Logger logger = LoggerFactory.getLogger(TemperatureController.class);

	
	private IotHubService iotHubService;
	public TemperatureController(IotHubService iotHubService, TemperatureRepository temperatureRepository) {
		this.iotHubService=iotHubService;
		this.temperatureRepository=temperatureRepository;
	}
	@CrossOrigin(origins ="http://127.0.0.1:5500")
	@PostMapping("/add")
	public ResponseEntity<String> addTemperature(@RequestBody Map<String, Object> temperature){
		try {
			
			iotHubService.sendTemperatureData(temperature);
		
		return ResponseEntity.ok("Temperature Recorded and sent to IOT HUB and Service Bus and stored in Database Successfully!");
		}catch (Exception e) {
			return ResponseEntity.badRequest().body("Error Converting data to JSON: "+e.getMessage());
		}
	}
	
    @CrossOrigin(origins = "http://127.0.0.1:5500")
    @PostMapping("/latest")
    public ResponseEntity<Temperature> getLatestTemperature(@RequestBody Map<String, String> request) {
        try {
            String atmId = request.get("atmId");
            Temperature latestTemperature = temperatureRepository.findTopByAtmIdOrderByidDesc(atmId);
            if (latestTemperature != null) {
                return ResponseEntity.ok(latestTemperature);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            logger.error("Error fetching latest temperature data", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
	@GetMapping("/all")
	public List<Temperature> getAllTemperature(){
		return temperatureRepository.getAllTemperatures();
	}
}
