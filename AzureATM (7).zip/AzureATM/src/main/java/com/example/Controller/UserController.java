package com.example.Controller;

import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.User;
import com.example.Repository.UserRepository;
@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://127.0.0.1:5500")
public class UserController {
	@Autowired
	private UserRepository userRepository;
	
	
	//SIGNUP
	
//	@GetMapping
//	public String hello() {
//		return "Hello Sarvesh";
//	}
    @CrossOrigin(origins = "http://127.0.0.1:5500")
	@PostMapping("/signup")
	public ResponseEntity<String> signUp(@RequestBody User user){
		int result=userRepository.addUser(user);
		return result>0? ResponseEntity.ok("User Registered Successfully!!"):ResponseEntity.badRequest().body("Error Registering User");
	}
	
	//SIGNIN
    @CrossOrigin(origins = "http://127.0.0.1:5500")
	@PostMapping("/signin")
	public ResponseEntity<String> signIn(@RequestBody User user){
		User authenticatedUser=userRepository.authenticateUser(user.getUsername(), user.getPassword());
		return(authenticatedUser !=null)
				?
						
						ResponseEntity.ok("Login Successfull! Role: "+authenticatedUser.getRole()):
							ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Credentials");
	}
	@CrossOrigin(origins = "http://127.0.0.1:5500")
    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestBody Map<String, String> request) {
        try {
            String username = request.get("username");
            String Mobile_number = request.get("Mobile_number");
            boolean isValid = userRepository.verifyUserByUsernameAndMobileNumber(username, Mobile_number);
            if (!isValid) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid user details");
            }
            String token = userRepository.generatePasswordResetToken(username);
            System.out.println("Generated Password Reset Token: " + token);
            // Send token to user via email or other means
            return ResponseEntity.ok("Password reset token sent!");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred: " + e.getMessage());
        }
    }


@CrossOrigin(origins = "http://127.0.0.1:5500")

@PostMapping("/reset-password")
public ResponseEntity<Map<String, String>> resetPassword(@RequestBody Map<String, String> request) {
    try {
        String token = request.get("token");
        String newPassword = request.get("newPassword");
        String confirmNewPassword = request.get("confirmNewPassword");
        if (!newPassword.equals(confirmNewPassword)) {
            return ResponseEntity.badRequest().body(Map.of("message", "Passwords do not match"));
        }
        String username = userRepository.getUsernameByPasswordResetToken(token);
        if (username == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Invalid token"));
        }
        int result = userRepository.updatePassword(username, newPassword);
        return result > 0 ? ResponseEntity.ok(Map.of("message", "Password Reset Successfully!!")) : ResponseEntity.badRequest().body(Map.of("message", "Error Resetting Password"));
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("message", "An error occurred: " + e.getMessage()));
    }
}


	
}
 