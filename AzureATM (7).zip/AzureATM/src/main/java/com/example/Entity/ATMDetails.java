package com.example.Entity;

public class ATMDetails {

	private int atm_id;
    private String atm_name;
    private int location_id;
	public int getAtmId() {
		return atm_id;
	}
	public void setAtmId(int atm_id) {
		this.atm_id = atm_id;
	}



	public String getAtm_name() {
		return atm_name;
	}
	public void setAtm_name(String atm_name) {
		this.atm_name = atm_name;
	}
	public int getLocation_id() {
		return location_id;
	}
	public void setLocation_id(int location_id) {
		this.location_id = location_id;
	}


}
