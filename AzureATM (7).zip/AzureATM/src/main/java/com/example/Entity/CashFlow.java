package com.example.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)

public class CashFlow {

	private int id;
    private int atm_id;
	private String updated_by;
	private int total_cash;
	private int notes_100;
	private int notes_200;
	private int notes_500;

	
	public CashFlow() {}
	
	public CashFlow( int atm_id,String updated_by,int total_cash, int notes_100,int notes_200,int notes_500) {
		this.setAtm_id(atm_id);
		this.updated_by=updated_by;
		this.total_cash=total_cash;
		this.notes_100=notes_100;
		this.notes_200=notes_200;
		this.notes_500=notes_500;


	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public int getTotalCash() {
		return total_cash;
	}

	public void setTotalCash(int totalCash) {
		this.total_cash = totalCash;
	}

	public int getNotes_100() {
		return notes_100;
	}

	public void setNotes_100(int notes_100) {
		this.notes_100 = notes_100;
	}

	public int getNotes_200() {
		return notes_200;
	}

	public void setNotes_200(int notes_200) {
		this.notes_200 = notes_200;
	}

	public int getNotes_500() {
		return notes_500;
	}

	public void setNotes_500(int notes_500) {
		this.notes_500 = notes_500;
	}

	public int getAtm_id() {
		return atm_id;
	}

	public void setAtm_id(int atm_id) {
		this.atm_id = atm_id;
	}


}
