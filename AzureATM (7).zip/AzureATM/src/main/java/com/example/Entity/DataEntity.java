package com.example.Entity;

public class DataEntity {

	private int id;
	private String type;
	private double value;

	public DataEntity() {
	}

	public DataEntity(String type, double value) {
		this.type = type;
		this.value = value;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}

	public String getRecorded_by() {
		return type;
	}

	public void setRecorded_by(String type) {
		this.type = type;
	}
}
