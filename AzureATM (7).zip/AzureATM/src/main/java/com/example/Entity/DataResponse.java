package com.example.Entity;

import java.util.List;

public class DataResponse {

    private List<DataEntity> temperature;
    private List<DataEntity> cashflow;
	public List<DataEntity> getTemperature() {
		return temperature;
	}
	public void setTemperature(List<DataEntity> temperature) {
		this.temperature = temperature;
	}
	public List<DataEntity> getCashflow() {
		return cashflow;
	}
	public void setCashflow(List<DataEntity> cashflow) {
		this.cashflow = cashflow;
	}

}
