package com.example.Entity;

public class Location {

    private int location_id;
    private String location_name;


	public int getLocationId() {
		return location_id;
	}
	public void setLocationId(int location_id) {
		this.location_id = location_id;
	}

	public String getLocation_name() {
		return location_name;
	}

	public void setLocation_name(String location_name) {
		this.location_name = location_name;
	}


}
