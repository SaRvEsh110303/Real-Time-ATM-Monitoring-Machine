package com.example.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Temperature {

    private int atm_id;
	private String recorded_by;
	private double value;

	public Temperature(){}
	
	public Temperature(int atm_id,String recorded_by,double value) {
		this.setAtm_id(atm_id);
		this.recorded_by=recorded_by;
		this.value=value;
		        
	}



	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public String getRecorded_by() {
		return recorded_by;
	}

	public void setRecorded_by(String recorded_by) {
		this.recorded_by = recorded_by;
	}

	public int getAtm_id() {
		return atm_id;
	}

	public void setAtm_id(int atm_id) {
		this.atm_id = atm_id;
	}





}
