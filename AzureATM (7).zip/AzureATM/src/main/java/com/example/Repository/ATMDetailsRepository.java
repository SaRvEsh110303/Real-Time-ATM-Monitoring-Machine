package com.example.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.Entity.ATMDetails;

@Repository
public class ATMDetailsRepository {

	 @Autowired
	    private final JdbcTemplate jdbcTemplate;

	    public ATMDetailsRepository(JdbcTemplate jdbcTemplate) {
	        this.jdbcTemplate = jdbcTemplate;
	    }

	    public int addATMDetails(ATMDetails atmDetails) {
	        String sql = "INSERT INTO ATM_Details(atm_name, location_id) VALUES (?, ?)";
	        return jdbcTemplate.update(sql, atmDetails.getAtm_name(), atmDetails.getLocation_id());
	    }

	    public List<ATMDetails> getAllATMDetails() {
	        String sql = "SELECT atm_id, atm_name, atm_status, location_id FROM ATMDetails";
	        return jdbcTemplate.query(sql, (rs, rowNum) -> {
	            ATMDetails atmDetails = new ATMDetails();
	            atmDetails.setAtmId(rs.getInt("atm_id"));
	            atmDetails.setAtm_name(rs.getString("atm_name"));
	            atmDetails.setLocation_id(rs.getInt("location_id"));
	            return atmDetails;
	        });
	    }
}
