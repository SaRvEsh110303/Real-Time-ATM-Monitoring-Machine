package com.example.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.Entity.DataEntity;
import com.example.Entity.DataResponse;

public class AzureRepository {


    @Autowired
    private JdbcTemplate jdbcTemplate;

    public DataResponse findLastTwoRows() {
        String temperatureQuery = "SELECT * FROM temperature_table ORDER BY id DESC LIMIT 2";
        String cashflowQuery = "SELECT * FROM cashflow_table ORDER BY id DESC LIMIT 2";

        List<DataEntity> temperature = jdbcTemplate.query(temperatureQuery, new BeanPropertyRowMapper<>(DataEntity.class));
        List<DataEntity> cashflow = jdbcTemplate.query(cashflowQuery, new BeanPropertyRowMapper<>(DataEntity.class));

        DataResponse dataResponse = new DataResponse();
        dataResponse.setTemperature(temperature);
        dataResponse.setCashflow(cashflow);

        return dataResponse;
    }

}
