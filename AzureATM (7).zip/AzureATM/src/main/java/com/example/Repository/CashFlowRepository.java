package com.example.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.Entity.CashFlow;

@Repository
public class CashFlowRepository {
	
	@Autowired
	private final JdbcTemplate jdbcTemplate;
	
	public CashFlowRepository(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate=jdbcTemplate;
	}
	
	public List<CashFlow> getAllCashFlows(){
		String sql="SELECT id,atm_id, updated_by,total_cash,notes_100,notes_200,notes_500 FROM CashFlow";
		return 
				jdbcTemplate.query(sql, 
						(rs,rowNum)->
				mapRowToCashFlow(rs));
						
	}
		public boolean cashFlowExists() {
			String sql="SELECT COUNT(*) FROM CashFlow";
			Integer count=jdbcTemplate.queryForObject(sql, Integer.class);
			return count!=null && count>0;
		}
		
		public int addOrUpdateCashFlow(CashFlow cashFlow) {
		    String checkSql = "SELECT COUNT(*) FROM CashFlow WHERE atm_id = ?";
		    Integer count = jdbcTemplate.queryForObject(checkSql, Integer.class, cashFlow.getAtm_id());

		    int totalCash = (cashFlow.getNotes_100()*100) + (cashFlow.getNotes_200()*200) + (cashFlow.getNotes_500()*500);
		    cashFlow.setTotalCash(totalCash);

		    if (count != null && count > 0) {
		        String updateSql = "UPDATE CashFlow SET updated_by = ?, notes_100 = ?, notes_200 = ?, notes_500 = ?, total_cash = ? WHERE atm_id = ?";
		        return jdbcTemplate.update(updateSql,
		            cashFlow.getUpdated_by(),
		            cashFlow.getNotes_100(),
		            cashFlow.getNotes_200(),
		            cashFlow.getNotes_500(),
		            cashFlow.getTotalCash(),
		            cashFlow.getAtm_id());
		    } else {
		        String insertSql = "INSERT INTO CashFlow (atm_id, updated_by, total_cash, notes_100, notes_200, notes_500) VALUES (?, ?, ?, ?, ?, ?)";
		        return jdbcTemplate.update(insertSql,
		            cashFlow.getAtm_id(),
		            cashFlow.getUpdated_by(),
		            cashFlow.getTotalCash(),
		            cashFlow.getNotes_100(),
		            cashFlow.getNotes_200(),
		            cashFlow.getNotes_500());
		    }
		}
		

@SuppressWarnings("deprecation")


public CashFlow findTopByAtmIdOrderByidDesc(String atmId) {
    String sql = "SELECT TOP 1 * FROM CashFlow WHERE atm_id = ? ORDER BY id DESC";
    return jdbcTemplate.queryForObject(sql, new Object[]{atmId}, (rs, rowNum) -> new CashFlow(
        rs.getInt("atm_id"),
        rs.getString("updated_by"),
        rs.getInt("total_cash"),
        rs.getInt("notes_100"),
        rs.getInt("notes_200"),
        rs.getInt("notes_500")
    ));
}


	private CashFlow mapRowToCashFlow(ResultSet rs) throws SQLException{
		
		return new CashFlow(
			rs.getInt("atm_id"),
			rs.getString("updated_by"),
			rs.getInt("total_cash"),
			rs.getInt("notes_100"),
			rs.getInt("notes_200"),
			rs.getInt("notes_500")
			);
	}

}
