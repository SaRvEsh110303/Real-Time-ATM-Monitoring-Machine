package com.example.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.Entity.Location;

@Repository
public class LocationRepository {

	   @Autowired
	    private final JdbcTemplate jdbcTemplate;

	    public LocationRepository(JdbcTemplate jdbcTemplate) {
	        this.jdbcTemplate = jdbcTemplate;
	    }

	    public int addLocation(Location location) {
	        String sql = "INSERT INTO Location(location_name) VALUES (?)";
	        return jdbcTemplate.update(sql, location.getLocation_name());
	    }

	    public List<Location> getAllLocations() {
	        String sql = "SELECT location_id, location_name FROM Location";
	        return jdbcTemplate.query(sql, (rs, rowNum) -> {
	            Location location = new Location();
	            location.setLocationId(rs.getInt("location_id"));
	            location.setLocation_name(rs.getString("location_name"));
	            return location;
	        });
	    }

}
