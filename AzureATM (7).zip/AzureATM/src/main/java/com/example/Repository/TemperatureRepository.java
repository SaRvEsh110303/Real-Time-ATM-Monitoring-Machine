package com.example.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.Entity.Temperature;

@Repository
public class TemperatureRepository {
	@Autowired
	private final JdbcTemplate jdbcTemplate;
	
	public TemperatureRepository(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate=jdbcTemplate;
	}
	
	public int addTemperature(Temperature temperature) {
		String sql="INSERT INTO Temperature(atm_id, recorded_by,temperature) VALUES (?,?,?)";
		return jdbcTemplate.update(sql,temperature.getAtm_id(), temperature.getRecorded_by(),temperature.getValue());
	}
	
	@SuppressWarnings("deprecation")
	public Temperature findTopByAtmIdOrderByidDesc(String atmId) {
	    String sql = "SELECT TOP 1 * FROM Temperature WHERE atm_id = ? ORDER BY id DESC";
	    return jdbcTemplate.queryForObject(sql, new Object[]{atmId}, (rs, rowNum) -> new Temperature(
	        rs.getInt("atm_id"),
	        rs.getString("recorded_by"),
	        rs.getDouble("temperature")
	    ));
	}
	public List<Temperature> getAllTemperatures(){
		String sql="SELECT id,atm_id,recorded_by, temperature,  FROM Temperature";
		return 
				jdbcTemplate.query(sql, (rs,rowNum)
						-> new Temperature(
								rs.getInt("atm_id"),
								rs.getString("recorded_by"),
								rs.getDouble("temperature")
								));
	}
}
