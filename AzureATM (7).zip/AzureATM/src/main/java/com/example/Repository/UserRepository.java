package com.example.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.Entity.User;
@Repository
public class UserRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;
    private Map<String, String> passwordResetTokens = new HashMap<>();

	public int addUser(User user) {
		String sql="INSERT INTO USERS(username,password,role) VALUES(?,?,?)";
		return jdbcTemplate.update(sql,user.getUsername(),user.getPassword(),user.getRole());
	}
	
	public User authenticateUser(String username,String password) {
			String sql="SELECT * FROM Users WHERE username = ? AND password= ?";
			List<User> users= jdbcTemplate.query(sql,new BeanPropertyRowMapper<User>(User.class),username,password);
			return users.isEmpty()?null :users.get(0);
	}
			
	
	public List<User> getUsers(){
		return jdbcTemplate.query("SELECT * FROM Users", 
			    (rs, rowNum) -> new 
			    
			    	User(
			    	rs.getInt("id"),
			    	rs.getString("username"),
			    	rs.getString("password"),
			    	rs.getString("role"))
			    	);
			
	}
    public String generatePasswordResetToken(String username) {
        String token = UUID.randomUUID().toString();
        passwordResetTokens.put(token, username);
        return token;
    }

    public boolean verifyPasswordResetToken(String token) {
        return passwordResetTokens.containsKey(token);
    }

    public int updatePasswordWithToken(String token, String newPassword) {
        String username = passwordResetTokens.get(token);
        if (username != null) {
            passwordResetTokens.remove(token);
            return updatePassword(username, newPassword);
        }
        return 0;
    }

    public int updatePassword(String username, String newPassword) {
        String sql = "UPDATE Users SET password = ? WHERE username = ?";
        return jdbcTemplate.update(sql, newPassword, username);
    }


    public boolean verifyUserByUsernameAndMobileNumber(String username, String Mobile_number) {
        // Verify the username exists in the database
        String sql = "SELECT COUNT(*) FROM Users WHERE username = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, username);

        // Additional validation for date of birth
        boolean isMobileNumberValid = validateMobileNumber(username, Mobile_number);

        return count != null && count > 0 && isMobileNumberValid;
    }

    private boolean validateMobileNumber(String username, String Mobile_number) {
        // Implement your logic to validate the date of birth here
        // For example, you could validate it using data from an external source or service
        return true; // Replace with actual validation logic
    }
    public String getUsernameByPasswordResetToken(String token) {
        return passwordResetTokens.get(token);
    }

}
