package com.example.Services;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Entity.DataResponse;
import com.example.Repository.AzureRepository;

public class DataService {

    @Autowired
    private AzureRepository azureApiRepository;

    public DataResponse getLastTwoRows() {
        return azureApiRepository.findLastTwoRows();
    }
}
