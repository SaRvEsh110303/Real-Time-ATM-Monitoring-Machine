package com.example.Services;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.Entity.CashFlow;
import com.example.Entity.Temperature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.sdk.iot.device.DeviceClient;
import com.microsoft.azure.sdk.iot.device.IotHubClientProtocol;
import com.microsoft.azure.sdk.iot.device.Message;
import com.microsoft.azure.sdk.iot.device.transport.IotHubConnectionStatus;
import com.microsoft.azure.sdk.iot.device.IotHubConnectionStatusChangeCallback;
import com.microsoft.azure.sdk.iot.device.IotHubConnectionStatusChangeReason;
import com.microsoft.azure.sdk.iot.device.IotHubStatusCode;

@Service
public class IotHubService {
	
//	private static final String TEMPERATURE_CONNECTION_STRING = "HostName=atmHub3.azure-devices.net;DeviceId=temperature;SharedAccessKey=SvapH0zSR8f97xgjE7nfLIlOTKeeset45/0Iyk7RBM4=";
	private static final String TEMPERATURE_CONNECTION_STRING = "HostName=AtmHub.azure-devices.net;DeviceId=Temperature;SharedAccessKey=WX/UKZ3p4d81BrPhyw4XdE7+ty6nKSfgTa/vDlxvpLc=";

	private static final String CASHFLOW_CONNECTION_STRING = "HostName=AtmHub.azure-devices.net;DeviceId=cashflow;SharedAccessKey=Kq8l3TaMql2OTZ1CEHMvf0UyCgKmG0QgQJFXxw/SsN8=";
	
	private final DeviceClient temperatureClient;
	private final DeviceClient cashflowClient;
	
	private static final IotHubClientProtocol PROTOCOL = IotHubClientProtocol.MQTT;
	
	
	public IotHubService() throws Exception {
        this.temperatureClient = new DeviceClient(TEMPERATURE_CONNECTION_STRING, PROTOCOL);
        this.cashflowClient= new DeviceClient(CASHFLOW_CONNECTION_STRING, PROTOCOL);
        temperatureClient.open(true);
        cashflowClient.open(true);
	}
	 
    public void sendTemperatureData(Map<String, Object> requestData) {
        // Extract other fields and create Temperature object (without deviceId in entity)
        Temperature tempData = new Temperature(
        	(int) requestData.get("atm_id"),
            (String) requestData.get("recorded_by"),
            (double) requestData.get("value")
        );
 
        sendToIoTHub(tempData,temperatureClient);
    }
    public void sendCashflowData(Map<String, Object> requestData) {
        CashFlow cashflowData = new CashFlow(
            (int) requestData.get("atm_id"),
            (String) requestData.get("updated_by"),
            (int) requestData.get("total_cash"),
            (int) requestData.get("notes_100"),
            (int) requestData.get("notes_200"),
            (int) requestData.get("notes_500")
        );
        sendToIoTHub(cashflowData,cashflowClient);
    }
 
    private void sendToIoTHub(Object data,DeviceClient client) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String jsonData = objectMapper.writeValueAsString(data);
            System.out.println("JSON Data: " + jsonData); // Print the JSON data

            Message message = new Message(jsonData);
            message.setProperty("type",data instanceof Temperature? "temp":"cashflow");
            message.setContentEncoding("utf-8");
            message.setContentEncoding("application/json");
            temperatureClient.sendEventAsync(message, null, null);
            System.out.println("data sent successfully!");
            System.out.println(jsonData);
        } catch (Exception e) {
            System.out.println("Error sending data: " + e.getMessage());
        }
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	private DeviceClient deviceClient;
//	private ObjectMapper objectMapper;
//
//	public IotHubService() throws Exception{
//		this.objectMapper=new ObjectMapper();
//		
//		String iotHubConnectionString="HostName=atmIotHub2.azure-devices.net;DeviceId=Atm_spring_device;SharedAccessKey=+EFjXPVd9/B/1zvrMUXkOTRBgKDsWPJpBeMCZi58E9A=";
//		this.deviceClient=new DeviceClient(iotHubConnectionString, IotHubClientProtocol.MQTT);
//		deviceClient.open(false);
//	}
//	public class UniqueIdGenerator {
//	    private static final Random random = new Random();
//
//	    public static String generateUniqueId() {
//	        long timestamp = System.currentTimeMillis();
//	        int randomNumber = random.nextInt(100000); // Generate a random number between 0 and 99999
//	        return timestamp + "-" + randomNumber;
//	    }
//	}
//	public void sendMessageToIotHubTemperature(Object temperature) throws Exception {
//	    Map<String, Object> messageData = new HashMap<>();
//	    System.out.println("hey I am temperature");
//	    messageData.put("type", "temperature");
//	    messageData.put("data", temperature);
//	    String jsonData = objectMapper.writeValueAsString(messageData);
//	    Message message = new Message(jsonData.getBytes(StandardCharsets.UTF_8));
//	    message.setMessageId(UniqueIdGenerator.generateUniqueId());
//	   System.out.println(message.getMessageId());
//	    System.out.println("Sending temperature message to IoT Hub: " + jsonData + " with ID: " + message.getMessageId());
//	    deviceClient.sendEventAsync(message, null, null);
//	    System.out.println("Data sent to IoT Hub Successfully");
//	    System.out.println("I run, you applied me I am temperature");
//	}
//
//	public void sendMessageToIotHubCashFlow(Object cashFlow) throws Exception {
//	    Map<String, Object> messageData = new HashMap<>();
//	    System.out.println("Hey I am cashflow");
//	    messageData.put("type", "cashflow");
//	    messageData.put("data", cashFlow);
//	    String jsonData = objectMapper.writeValueAsString(messageData);
//	    Message message = new Message(jsonData.getBytes(StandardCharsets.UTF_8));
//	    message.setMessageId(UniqueIdGenerator.generateUniqueId());
//		   System.out.println(message.getMessageId());
//	    System.out.println("Sending cashflow message to IoT Hub: " + jsonData + " with ID: " + message.getMessageId());
//	    deviceClient.sendEventAsync(message, null, null);
//	    System.out.println("Data sent to IoT Hub Successfully");
//	    System.out.println("I run you applied me");
//	}

}
