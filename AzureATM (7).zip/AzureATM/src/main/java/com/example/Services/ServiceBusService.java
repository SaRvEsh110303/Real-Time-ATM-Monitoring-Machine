package com.example.Services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusProcessorClient;
import com.azure.messaging.servicebus.ServiceBusReceivedMessage;
import com.azure.messaging.servicebus.ServiceBusReceivedMessageContext;
import com.azure.messaging.servicebus.ServiceBusReceiverAsyncClient;
import com.azure.messaging.servicebus.implementation.ServiceBusProcessorClientOptions;
import com.example.Entity.CashFlow;
import com.example.Repository.CashFlowRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ServiceBusService {

	@Autowired
	private final CashFlowRepository cashFlowRepository;
    private static final String SERVICE_BUS_CONNECTION_STRING = "Endpoint=sb://cashflowservice2.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=kbumEj6jUf297zzhj5QUrscv9ozQFATfo+ASbF25A4Y=";
    private static final String CASHFLOW_TOPIC_NAME = "cashflowtopic";
    private static final String CASHFLOW_SUBSCRIPTION_NAME = "cashflowsubscription";

    private final ServiceBusProcessorClient processorClient;

    public ServiceBusService(CashFlowRepository cashFlowRepository) {
    	this.cashFlowRepository=cashFlowRepository;
        this.processorClient = new ServiceBusClientBuilder()
            .connectionString(SERVICE_BUS_CONNECTION_STRING)
            .processor()
            .topicName(CASHFLOW_TOPIC_NAME)
            .subscriptionName(CASHFLOW_SUBSCRIPTION_NAME)
            .processMessage(this::processMessage)
            .processError(context -> System.out.println("Error occurred: " + context.getException().getMessage()))
            .buildProcessorClient();

        this.processorClient.start();
    }

    private void processMessage(ServiceBusReceivedMessageContext context) {
        ServiceBusReceivedMessage message = context.getMessage();
        String jsonData = message.getBody().toString();
        System.out.println("Received JSON Data: " + jsonData);

        try {
            CashFlow cashflowData = new ObjectMapper().readValue(jsonData, CashFlow.class);
            // Add logging before updating the database

            System.out.println("Attempting to update database with data: " + cashflowData);
            cashFlowRepository.addOrUpdateCashFlow(cashflowData);
            System.out.println("Data added successfully into database");
        } catch (Exception e) {
            System.out.println("Error processing received data: " + e.getMessage());
            e.printStackTrace(); // Print stack trace for more detailed error information
        } 
    }
}
